// Helper function for getting a checksum of a URL
function hashTextWithSHA3_512(text) {
    const shaObj = new jsSHA("SHA3-512", "TEXT", { encoding: "UTF8" });
    shaObj.update(text);
    return shaObj.getHash("HEX");
}

function getSearchQueryFromURL(url) {

  const urlObj = new URL(url);  

  let queryParam;

  switch (urlObj.hostname) {

    case 'www.google.com':
    case 'www.bing.com':
    case 'duckduckgo.com':
    case 'search.yahoo.com':
    case 'search.aol.com':
    case 'www.ask.com':
    case 'www.dogpile.com':
    case 'www.ecosia.org': 
    case 'www.mojeek.com':
    case 'www.webcrawler.com':
    case 'www.info.com':
    case 'www.zapmeta.com':
    case 'www.goodsearch.com':
    case 'www.hotbot.com':
    case 'www.teoma.com':
    case 'www.contenko.com':
      queryParam = 'q';
      break;

    case 'yandex.com':
      queryParam = 'text';
      break;

    case 'www.baidu.com':  
      queryParam = 'wd';
      break;

    case 'www.sogou.com':
    case 'swisscows.com':
      queryParam = 'query';
      break;

    case 'metager.org':
      queryParam = 'eingabe';
      break;

    default:
      return null;

  }

  const query = urlObj.searchParams.get(queryParam);

  return query ? query.replace(/\\+/g, ' ') : null; 

}

// In-memory cache for checksums
let queryChecksumsCache = [];
let urlChecksumsCache = [];

// Function to load checksums from storage to cache
function loadChecksums() {
    browser.storage.local.get(["queryChecksums", "urlChecksums"]).then((result) => {
        queryChecksumsCache = result.queryChecksums || [];
        urlChecksumsCache = result.urlChecksums || [];
    });
}

// Listen for changes in the storage and update the cache accordingly
browser.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local') {
        if (changes.queryChecksums) {
            queryChecksumsCache = changes.queryChecksums.newValue || [];
        }
        if (changes.urlChecksums) {
            urlChecksumsCache = changes.urlChecksums.newValue || [];
        }
    }
});

// Load the checksums into the cache when the extension starts
loadChecksums();

// Function to load checksums from storage to cache
function loadChecksums() {
    browser.storage.local.get(["queryChecksums", "urlChecksums"]).then((result) => {
        queryChecksumsCache = result.queryChecksums || [];
        urlChecksumsCache = result.urlChecksums || [];
    });
}

// Load the checksums into the cache when the extension starts
loadChecksums();

// Listen for web requests for search queries
browser.webRequest.onBeforeRequest.addListener(
    (details) => {
        let searchQuery = getSearchQueryFromURL(details.url);
        if (searchQuery) {
            let checksum = hashTextWithSHA3_512(searchQuery);
            if (queryChecksumsCache.includes(checksum)) {
                return { redirectUrl: browser.extension.getURL("warning.html") }; // Redirect to warning page
            }
        }
        return {cancel: false};
    },
    {urls: ["<all_urls>"]},
    ["blocking"]
);

function getChecksum(url) {
    // Create a URL object from the URL string
    const urlObj = new URL(url);
    
    // Extract the domain name without any subdomains
    const parts = urlObj.hostname.split('.');
    const topLevelDomain = parts.length > 1 ? parts.slice(-2).join('.') : urlObj.hostname;
    
    // Hash the top-level domain
    return hashTextWithSHA3_512(topLevelDomain);
}

// Listen for web requests for URLs
browser.webRequest.onBeforeRequest.addListener(
    (details) => {
        let checksum = getChecksum(details.url);
        if (urlChecksumsCache.includes(checksum)) {
            return { redirectUrl: browser.extension.getURL("warning.html") }; // Redirect to warning page
        }
        return {cancel: false};
    },
    {urls: ["<all_urls>"]},
    ["blocking"]
);